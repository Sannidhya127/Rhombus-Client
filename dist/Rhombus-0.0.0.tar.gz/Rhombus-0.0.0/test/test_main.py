from rhombus import CheckLogin, sendMail

sendMail()